package helloworld;

public class HelloWorld{
    public static void say(){
        System.out.println("Hello World\n");
    }
}