package aplusb;

public class APlusB{
    public int plus(int a, int b){
        return a + b;
    }
}